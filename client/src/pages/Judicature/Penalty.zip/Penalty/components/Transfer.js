<<<<<<< HEAD
import React, { useState } from 'react';
import { Component } from 'react';

import Autocomplete from '@material-ui/lab/Autocomplete';
import { makeStyles } from '@material-ui/core/styles';
import TextField from '@material-ui/core/TextField';
import NumberFormat from 'react-number-format';
import "../../../../styles/css/transfer.css"


const useStyles = makeStyles((theme) => ({
    root: {
      width: 500,
      '& > * + *': {
        marginTop: theme.spacing(3),
      },
    },
  }));


  const inputStyles = makeStyles((theme) => ({
    root: {
      width: 100,
      height: 75,
      '& > * + *': {
        marginTop: theme.spacing(3),
      },
    },
  }));

// class에서 student_list 받아오기





function NumberFormatCustom(props) {
    const { inputRef, onChange, ...other } = props;
  
    return (
      <NumberFormat
        {...other}
        getInputRef={inputRef}
        onValueChange={(values) => {
          onChange({
            target: {
              name: props.name,
              value: values.value,
            },
          });
        }}
        thousandSeparator
        isNumericString
        prefix="$ "
      />
    );
  }

class Transfer extends Component {

render(){

    return(
    <div className="col-lg-8 justify-content-center">

        <Autocomplete className="py-3"
        style={{useStyles}}
        options={this.props.laws}
        variant="outlined"
        getOptionLabel={(option) => option.title}
        required

        renderInput={(params) => <TextField {...params} label="법률" variant="outlined" />} />

        <Autocomplete className="py-3"
        style={{useStyles}}
        options={this.props.users}
        variant="outlined"
        getOptionLabel={(option) => option.name}
        required

        renderInput={(params) => <TextField {...params} label="받는사람 이름" variant="outlined" />} />


<div className="row justify-content-center">
<div className="row m-4 input_fine justify-content-center align-items-center">
        
        <TextField 
            className="bg-white"
            style={{inputStyles}}
            required
            variant="outlined"
            defaultValue="0"
            
            name="numberformat"

            InputProps={{
          inputComponent: NumberFormatCustom,
        }}
      />
      </div></div>


        <div className="d-flex justify-content-center py-3">
            <div className="p-2 btn btn-primary"> 부과하기 </div>
        </div>
       
   </div>
    )
}
}

export default Transfer;
=======
import React, { useState } from "react";
import Autocomplete from "@material-ui/lab/Autocomplete";
import { makeStyles } from "@material-ui/core/styles";
import TextField from "@material-ui/core/TextField";
import NumberFormat from "react-number-format";
import { Button } from "@material-ui/core";
import "../../../../styles/css/transfer.css";
import axios from "axios";
import { useSelector} from 'react-redux';


const useStyles = makeStyles((theme) => ({
  root: {
    width: 500,
    "& > * + *": {
      marginTop: theme.spacing(3),
    },
  },
}));

const inputStyles = makeStyles((theme) => ({
  root: {
    width: 100,
    height: 75,
    "& > * + *": {
      marginTop: theme.spacing(3),
    },
  },
}));

// class에서 student_list 받아오기

function NumberFormatCustom(props) {
  const { inputRef, onChange, ...other } = props;

  return (
    <NumberFormat
      {...other}
      getInputRef={inputRef}
      onValueChange={(values) => {
        onChange({
          target: {
            name: props.name,
            value: values.value,
          },
        });
      }}
      thousandSeparator
      isNumericString
      prefix="$ "
    />
  );
}

function Transfer(props){

  const [lawReason,setLaw] = useState(null);
  const [studentId, setStudent] = useState(null);
  const [Amount, setAmount] = useState(0);
 
  // 리덕스에 있는 정보 가져오기!
  let classData = useSelector(state => state.classInfo.classData);

  const studenthandleChange= (e,values)=>{
    e.preventDefault();
    setStudent(values);
  } 
    
  const lawhandleChange= (e,values)=>{
    e.preventDefault();
    setLaw(values);
  }
    
    
  const AmounthandleChange=(e)=>{
    setAmount(e.target.value);
  }

  const handleSubmit=(e) =>{
  
    const data={
      classId: classData.classId,
      lawReason,
      studentId,
      Amount,
    }
    axios.post(`/api/fine/`,data)
    .then(function (response) {
      console.log(response);
    })
    .catch(function (error) {
      console.log(error);
      console.log('testing fine error');
    });
    
  };
  return (
    <div className="col-lg-8 justify-content-center">
    <form onSubmit={handleSubmit}>
      <Autocomplete
        className="py-3"
        style={{ useStyles }}
        options={props.laws}
        variant="outlined"
        getOptionLabel={(option) => option.title}
        required
        name="Law"
        onChange={lawhandleChange}
        renderInput={(params) => (
          <TextField {...params} label="법률" variant="outlined" />
        )}
  
      />

      <Autocomplete
        className="py-3"
        style={{ useStyles }}
        options={props.users}
        variant="outlined"
        onChange={studenthandleChange}
        getOptionLabel={(option) => option.name}
        required
        renderInput={(params) => (
          <TextField {...params} label="받는사람 이름" variant="outlined" name="Student"/>
        )}
      />

      <div className="row justify-content-center">
        <div className="row m-4 input_fine justify-content-center align-items-center">
          <TextField
            className="bg-white"
            style={{ inputStyles }}
            required
            variant="outlined"
            onChange={AmounthandleChange}
            defaultValue="0"
            name="Amount"
            InputProps={{
              inputComponent: NumberFormatCustom,
            }}
          />
        </div>
      </div>

      <div className="d-flex justify-content-center py-3">
        <Button color="primary" type="submit">
          부과하기
        </Button>
      </div>
    </form>
  </div>
  )
}

export default Transfer;
>>>>>>> 0ba7923da5bfaa660aeb4b294b9cf873cb322ecd
